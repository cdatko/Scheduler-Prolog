--------------------------------
	Contents
--------------------------------
	1) scheduler.pro	
	2) scheduler.log
	3) readme.txt

--------------------------------
	File Description
--------------------------------
	scheduler.pro - Main file which contains all the predicates necessary
		that given lab needs and TA resources, a solution matching TA's 
		to labs can be found.

	scheduler.log - Log file of 2 test cases for each predicate.

	readme.txt - This.

--------------------------------
	Pledge
--------------------------------

	On my honor I have neither given nor received aid on this
	exam
	SIGN Christopher R. Datko
